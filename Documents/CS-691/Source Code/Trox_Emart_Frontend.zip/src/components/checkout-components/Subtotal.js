import React from 'react';
import CurrencyFormat from 'react-currency-format';

const Subtotal = () => {
    return (
        <div className="subTotal">
            
            <button>Proceed to checkout</button>
        </div>
    )
};

export default Subtotal;